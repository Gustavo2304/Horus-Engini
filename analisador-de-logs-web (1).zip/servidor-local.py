#!/usr/bin/env python3
"""Servidor local para testar o site no seu computador.

Uso:   python servidor-local.py          (Windows: py servidor-local.py)
       python servidor-local.py 9000     (outra porta)
       python servidor-local.py --no-abrir

Por que não usar só `python -m http.server`? No Windows, o Python lê os tipos de arquivo do
registro do sistema; quando .css/.js estão mal configurados lá, o navegador recebe "text/plain",
ignora o CSS e recusa os módulos JavaScript (a página aparece sem estilo e sem funcionar).
Este servidor fixa os tipos corretos.
"""
import http.server
import os
import socketserver
import sys
import threading
import webbrowser

args = [a for a in sys.argv[1:] if not a.startswith("--")]
PORT = int(args[0]) if args else 8000
OPEN_BROWSER = "--no-abrir" not in sys.argv

os.chdir(os.path.dirname(os.path.abspath(__file__)))

TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".log": "text/plain; charset=utf-8",
    ".txt": "text/plain; charset=utf-8",
    ".md": "text/plain; charset=utf-8",
}


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map, **TYPES}

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")  # sempre mostra a versão mais recente dos arquivos
        super().end_headers()


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    try:
        httpd = Server(("127.0.0.1", PORT), Handler)
    except OSError as err:
        sys.exit(f"Não foi possível usar a porta {PORT} ({err}). Tente outra: python servidor-local.py 9000")
    url = f"http://localhost:{PORT}/"
    print(f"Site disponível em {url}\nPara parar, pressione Ctrl+C.")
    if OPEN_BROWSER:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor encerrado.")
    finally:
        httpd.server_close()
