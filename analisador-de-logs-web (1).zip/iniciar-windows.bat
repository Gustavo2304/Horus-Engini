@echo off
cd /d "%~dp0"
echo Iniciando o servidor local... (pressione Ctrl+C ou feche esta janela para parar)
python servidor-local.py
pause
